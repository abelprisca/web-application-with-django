from django.urls import path

from . import views 

urlpatterns = [
    path("<int:id>", views.index, name="index"),
    path("", views.home, name="home"),
    path("create/", views.create, name="create"),
    path("about/", views.about, name="about"),
    path("profile/", views.profile, name="about"),
    path("event/", views.event, name="event"),
    path("create_student/", views.create_student, name="create_student"),
    path("department/", views.department, name="department"),
    path('contact/', views.contact_view, name='contact'),
    path('enroll/', views.enroll, name='enroll'),
    path('news/', views.news, name='news'),
    path('post/', views.post, name='post'),
    path('logout/', views.logout, name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('help/', views.help, name='help'),
    path('login/', views.login_view, name='login'),
    path('todo_list/', views.todo_view, name='todo-list')


    
    
   

    
]