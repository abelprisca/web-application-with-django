from django.db import models







# Create your models here.

class ToDoList(models.Model):
    name = models.CharField(default='name', max_length=20)
   

    def __str__(self):
        return self.name
    

class iteam(models.Model):
    todolist = models.ForeignKey(ToDoList, on_delete=models.CASCADE)
    text = models.CharField(max_length=200)
    complete = models.BooleanField()

    def __str__(self):
        return self.text

class Student(models.Model):
    fullname = models.CharField(default='Full Name', max_length=30)
    username = models.CharField(default="username", max_length=100)
    email = models.CharField(default="email", max_length=30)
    phonenumber = models.CharField(default='Phone Number', max_length=30)
    nextofkin =models.CharField(default='Next of Kin', max_length=100)
    nextofkinphone = models.CharField(default='Next of Kin Phone Number', max_length=30)
    student_expert = models.CharField(default='student', max_length=10)
    professional = models.CharField(default='professional', max_length=10)

    
    def __str__(self):
        return self.fullname
    
class contact(models.Model):
    uname = models.CharField(default='uname', max_length=30)
    postemail = models.CharField(default="pmail", max_length=100)
    message = models.CharField(default="message", max_length=100)

    def __str__(self):
        return self.uname

 

class Enrollment(models.Model):


    idname = models.CharField(default='UserName', max_length=100)
    idemail = models.EmailField(default='Email', unique=True)
    title =models.CharField(default='Title', max_length=200)
    description = models.CharField(default='Description', max_length=79)
    course =models.CharField(default='Course', max_length=100)
    student = models.CharField(default='years/month', max_length=30)
    enrolled_date = models.DateTimeField()

    def __str__(self):
        return self.idemail

 
 
class Post(models.Model):
    usernameid = models.CharField(default='usernam', max_length=55)
    emailid= models.CharField(default='email', max_length=89)
    title = models.CharField(max_length=250)
    slug = models.SlugField(max_length=250)
    
    body = models.CharField(default="post here", max_length=300)
    publish = models.DateTimeField()
    
    
    def __str__(self):
        return self.title
    

class TodoItem(models.Model):
    todoname = models.CharField( default='NAME', max_length=200, unique=True)
    todoemail = models.CharField( default='EMAIL', max_length=200, unique=True) 
    title = models.CharField( default='Title', max_length=200, unique=True)
    description = models.CharField(default='Description', max_length=200)
    date = models.DateTimeField()

    
    def __str__(self):
        return self.title
    





    
    
   


    
   
