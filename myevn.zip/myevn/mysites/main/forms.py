from django import forms


class CreateNewList(forms.Form):
    name = forms.CharField(label="Name", max_length=200)
    I_agree= forms.BooleanField(required=False)

class CreateStudentForm(forms.Form):
    fullname = forms.CharField(label='Full Name', max_length=30)
    username =forms.CharField(label='UserName', max_length=100)
    email = forms.CharField(label='Email Address', max_length=30)
    check= forms.BooleanField( label='verify you are Human', required=True)
    phonenumber = forms.CharField(label='Phone Number', max_length=30)
    nextofkin =forms.CharField(label='Next of Kin', max_length=100)
    nextofkinphone = forms.CharField(label='Next of Kin Phone Number', max_length=30)
    student_expert = forms.CharField(label='Are you Depris Tech Student', max_length=10)
    verify= forms.BooleanField( label='verify', required=True)
    professional = forms.CharField(label='Professional', max_length=10)
    despr= forms.CharField( label='Describe your professionals', required=False, max_length=12)
    valid = forms.BooleanField( label='verify', required=True)


class ListContact(forms.Form):
    uname = forms.CharField(label='Username', max_length=30)
    postemail = forms.CharField(label="Post EMAIL",  max_length=100)
    message = forms.CharField(label='Message',  widget=forms.Textarea,  max_length=100)
    check= forms.BooleanField( label='Verify You are Human', required=True)
   
class CourseForm(forms.Form):
    idname = forms.CharField(label='UserName', max_length=100)
    idemail = forms.EmailField(label='Email')
    title =forms.CharField(label='Title', max_length=200)
    description = forms.CharField(label='Description', max_length=79)
    course =forms.CharField(label='Course', max_length=100)
    student = forms.CharField(label='years/month', max_length=30)
    enrolled_date = forms.DateTimeField()


class PostForm(forms.Form):
    usernameid = forms.CharField(label='Username', max_length=55)
    emailid= forms.CharField(label='Email', max_length=89)
    title = forms.CharField(label="Post Title", max_length=250)
    slug = forms.SlugField(max_length=250)
    body = forms.CharField(label="Post Here",  widget=forms.Textarea, max_length=300)
    publish = forms.DateTimeField()
    sure =forms.BooleanField( label='Verify You are Human', required=True)

class TodoItemForm(forms.Form):
    todoname  = forms.CharField( label='UserName', max_length=200)
    todoemail = forms.CharField(label='Email', max_length=200)
    title = forms.CharField( label='Title', max_length=200)
    description = forms.CharField(label='Description', widget=forms.Textarea, max_length=200)
    date = forms.DateTimeField()
    complete =forms.BooleanField( label='Complete', required=True)


    



