from django.shortcuts import render, redirect
from django.http import HttpResponse, HttpResponseRedirect
from .models import ToDoList, iteam,  Student, contact, Enrollment, Post, TodoItem 
from .forms import CreateStudentForm,  CreateNewList, ListContact, CourseForm, PostForm, TodoItemForm
from django.utils.text import slugify


# Create your views here.

def index(reponse, id):
    ls = ToDoList.objects.get(id=id)

    if reponse.method == "POST":    
        print(reponse.POST)
        if reponse.POST.get("save"):
             for iteam in ls.iteam_set.all():
                    if reponse.POST.get("c" + str(iteam.id)) == "clicked":
                       iteam.complete = True
                    else:
                       iteam.complete = False

                    iteam.save()
        elif reponse.POST.get("newiteam"):
            
            txt = reponse.POST.get("new")

            if len(txt) > 2:
                 ls.iteam_set.create(text = txt, complete =False )
            else:
                 print("invalid")
            
        
    return  render(reponse, "main/list.html", {"ls":ls})

def home(response):
    return  render(response, "main/home.html", {})

def create(response):
        if response.method=="POST":
            form=CreateNewList(response.POST)
            
            if form.is_valid():
                n = form.cleaned_data["name"] 
                t= ToDoList(name=n)
                t.save()
            return HttpResponseRedirect("/%i" %t.id)
             
        else:
            form = CreateNewList()
            
        return render(response, "main/create.html", {"form":form})
def about(response):
    return  render(response, "main/about.html", {})
def profile(response):
    return  render(response, "main/profile.html", {})
def event(response):
    return  render(response, "main/event.html", {})

def create_student(request):
    if request.method == 'POST':
        form = CreateStudentForm(request.POST)
        if form.is_valid():
            student = Student(
                fullname=form.cleaned_data['fullname'],
                username=form.cleaned_data['username'],
                email=form.cleaned_data['email'],
                student_expert=form.cleaned_data['student_expert'],
                professional=form.cleaned_data['professional']
            )
            student.save()
            return HttpResponse(
    '<h2>Student Registered with Name:</h2> ' + student.fullname + 
    '<h2><p>Email Address:</p> </h2>' + student.email + 
    '<h1><p>Thank you for Registering with DePris Tech</p></h1>' + 
    '<h1>Congratulations</h1> ' + student.fullname + 
    '<h2>Your DePris Tech journey begins now!</h2>' + 
    '<h3>Your unique username is: ' + student.username + '@depristech</h3>' + 
    '<p>You can now enroll in a course and start exploring the world of DePris Tech. Welcome to our community!</p>'
)

    else:
        form = CreateStudentForm()
    return render(request, 'main/create_student.html', {"form": form})
def department(response):
    return  render(response, "main/department.html", {})

        


        
def contact_view(request):
    if request.method == 'POST':
        form = ListContact(request.POST)
        if form.is_valid():
            contact.objects.create(
                uname = form.cleaned_data['uname'], 
                postemail= form.cleaned_data['postemail'], 
                message = form.cleaned_data['message'] 
            )
            return HttpResponse("<h1>Thank You for Contacting Us!</h1><p>We appreciate your message and will get back to you soon.</p>")

    else:
        form = ListContact()
    return render(request, "main/contact.html", {'form':form})



def enroll(request):
    if request.method == 'POST':
        form = CourseForm(request.POST)
        if form.is_valid():
            idname = form.cleaned_data['idname']
            if '@depristech' not in idname:
                return HttpResponse('ID Name must contain @depristech')
            Enrollment.objects.create(
                idname=idname,
                idemail=form.cleaned_data['idemail'],
                title=form.cleaned_data['title'],
                description=form.cleaned_data['description'],
                course=form.cleaned_data['course'],
                student=form.cleaned_data['student'],
                enrolled_date=form.cleaned_data['enrolled_date']
            )
            return HttpResponse("Congratulations on taking the first step towards achieving your goals! We're thrilled to have you on board and excited to support you every step of the way on this learning journey. We will review your request and follow up with you within the next week ")
    else:
        form = CourseForm()
    return render(request, 'main/enroll.html', {'form': form})

def news(response):
    return  render(response, "main/news.html", {})


def post(request):
    if request.method == 'POST':
        form = PostForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['usernameid']
            if '@depristech' in username:
                Post.objects.create(
                    usernameid=form.cleaned_data['usernameid'],
                    emailid=form.cleaned_data['emailid'],
                    title=form.cleaned_data['title'],
                    body=form.cleaned_data['body'],
                    publish=form.cleaned_data['publish'],
                    slug=slugify(form.cleaned_data['title']),
                )
                return HttpResponse(
                    '<h2>Post Submitted by:</h2> ' + username +
                    '<h2><p>Email Address:</p> </h2>' + form.cleaned_data['emailid'] +
                    '<h1><p>Thank you for submitting your post!</p></h1>' +
                    '<h1>Congratulations</h1> ' + username +
                    '<h2>Your post has been successfully submitted!</h2>' +
                    '<h3>We appreciate your contribution to DePris Tech.</h3>' +
                    '<p>We will be in touch with you shortly to discuss further.</p>' +
                    '<p>Thanks again for choosing DePris Tech!</p>'
                )
            else:
                return HttpResponse("Username must contain @depristech")
        else:
            return HttpResponse("Invalid form data")
    else:
        form = PostForm()
        return render(request, 'main/post.html', {'form': form})


def logout(response):
    return  render(response, "main/logout.html", {})


def dashboard(response):
    return  render(response, "main/dashboard.html", {})


def help(response):
    return  render(response, "main/help.html", {})

def login_view(response):
    return  render(response, "main/login.html", {})


def todo_view(request):
    if request.method == 'POST':
        form = TodoItemForm(request.POST)
        if form.is_valid():
            TodoItem.objects.create(
                todoname=form.cleaned_data['todoname'],
                todoemail=form.cleaned_data['todoemail'],
                title=form.cleaned_data['title'],
                description=form.cleaned_data['description'],
                date=form.cleaned_data['date']
            )
            return HttpResponse('Todo item added successfully!')
    else:
        form = TodoItemForm()
    return render(request, 'main/todo_list.html', {'form': form})








