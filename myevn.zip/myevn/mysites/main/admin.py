from django.contrib import admin
from .models import ToDoList,iteam, Student, contact, Enrollment, Post, TodoItem

# Register your models here.
admin.site.register(ToDoList)
admin.site.register(iteam)
admin.site.register(Student)
admin.site.register(contact)
admin.site.register(Enrollment)
admin.site.register(Post)
admin.site.register(TodoItem)

